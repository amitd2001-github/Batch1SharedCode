package com.softra;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Entity
@IdClass(PersonKey.class)
public class Person {

	//@EmbeddedId
	//private PersonKey pk;
	
	@Id
	private int ssn;
		
	@Id
	private int passportno;
		
	@Column(name="name")
	private String name;
}
