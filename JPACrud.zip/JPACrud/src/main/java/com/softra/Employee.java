package com.softra;

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;
import javax.persistence.Column;

/**
 * Entity implementation class for Entity: Employee
 *
 */
@Entity
@Table(name="employee")
public class Employee implements Serializable {

		
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;

    @Column(name="firstname")
    private String fname;
	
    @Column(name="lastname")
    private String lname;
	
	
	
	public Employee() {
		super();
	}   

	
	
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}   
	public String getFname() {
		return this.fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}   
	public String getLname() {
		return this.lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}
	
	public String toString(){
		return id + fname;
	}
   
}
