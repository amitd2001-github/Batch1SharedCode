package com.softra;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.IdClass;

@Embeddable
public class PersonKey implements Serializable {

	@Column(name="ssnn",nullable=false)
	private int ssn;
	
	@Column(name="passportnon",nullable=false)
	private int passportno;
}
