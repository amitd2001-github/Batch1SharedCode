package com.softra.dao;

import java.util.List;

import com.softra.Employee;

public interface IDao {
	
	int createEmployee(int id, String fname, String lname);
	
	boolean updateEmployee(int id,String newfname);
	
	boolean removeEmployee(int id);
	
	public List<Employee> getEmployees();
	

}
