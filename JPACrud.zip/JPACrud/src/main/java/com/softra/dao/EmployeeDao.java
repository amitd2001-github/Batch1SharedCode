package com.softra.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.transform.ResultTransformer;

import com.softra.Address;
import com.softra.Employee;
import com.softra.utility.EntityManagerHelper;

public class EmployeeDao implements IDao {

	@Override
	public int createEmployee(int id, String fname, String lname) {
		Employee e = new Employee(); // Transient State
		e.setFname(fname);
		e.setLname(lname);
		
		Address a = new Address("pumbai","411004");
		e.setAddr(a);
				
		EntityManager em = EntityManagerHelper.getEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(e);              // Managed State
		System.out.println("Employee added with empId: "+ id);
		em.flush();
		tx.commit();
		em.close();
		return id;

	}
	
	@Override
	public boolean updateEmployee(int id, String newfname) {
		EntityManager em = EntityManagerHelper.getEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Employee e = em.find(Employee.class, id); //persistent state
		if(e == null) {
			return false;
		}
		e.setFname(newfname);
		em.merge(e);
		System.out.println("Employee updated with empId: "+ id);
		em.flush();
		tx.commit();
		em.close();
		return true;
		
	}

	@Override
	public boolean removeEmployee(int id) {
		EntityManager em = EntityManagerHelper.getEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		Employee e = em.find(Employee.class, id); //persistent state
		if(e == null) {
			return false;
		}
		
		em.remove(e);
		System.out.println("Employee deleted with empId: "+ id);
		em.flush();
		tx.commit();
		em.close();
		return true;
	}

	@Override
	public List<Employee> getEmployees() {
		EntityManager em = EntityManagerHelper.getEntityManager();	
		List<Employee> list = em.createQuery("FROM Employee").getResultList();
		em.close();
		return list;
	}

	
}
