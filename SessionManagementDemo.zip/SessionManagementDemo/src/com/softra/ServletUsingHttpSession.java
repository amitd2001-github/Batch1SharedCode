package com.softra;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServletUsingHttpSession
 */
public class ServletUsingHttpSession extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	//This is a default constructor of my Servlet
    public ServletUsingHttpSession() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		 HttpSession session = request.getSession(true); //change the value from false to true
		
		 String name = request.getParameter("attrib_name");
		 String value = request.getParameter("attrib_value");
		 String remove = request.getParameter("attrib_remove");
		 
		 if (name != null && name.length() > 0 && (value != null) 
	              && value.length() > 0) {
			if(session != null) {
				session.setAttribute(name, value);
			}
	        
	      } 
		
		 out.println("<HTML>");
		 out.println("<HEAD><TITLE>Session Attributes with HttpSession</TITLE></HEAD>");
		 out.println("<BODY>");
		 out.println("<H1>Session Attributes with HttpSession</H1>");
		 
		 out.println("Enter name and value of an attribute");
		 //create a HTML Form
		 String url = "/SessionManagementDemo/session";
		 out.println("<FORM ACTION=" + "'" + url + "'" +  " " + "METHOD=GET" + " >");
		 out.println("Item: ");
		 out.println("<INPUT TYPE=\"text\" SIZE=\"10\" NAME=\"attrib_name\">");
		 out.println("Quantity: ");
		 out.println("<INPUT TYPE=\"text\" SIZE=\"10\" NAME=\"attrib_value\">");
		 out.println("<BR><INPUT TYPE=\"checkbox\" NAME=\"attrib_remove\">Remove");
		 out.println("<INPUT TYPE=\"submit\" NAME=\"update\" VALUE=\"Update\">");
		 out.println("</FORM>");
		 
		 out.println("<HR>");
		 out.println("Attributes in this Session using HttpSession");
		 if(session!= null) {
		 Enumeration e = session.getAttributeNames();
		    while (e.hasMoreElements()) {
		      String att_name = (String) e.nextElement();
		      String att_value = (String) session.getAttribute(att_name);

		      out.println("<BR><B>Item:</B> ");
		      out.println(att_name);
		      out.println("<B>Quantity: </B>");
		      out.println(att_value);
		    } 
		 }
		 else {
			  out.println("<BR><B>Name:</B> ");
		      out.println(name);
		      out.println("<B>Value: </B>");
		      out.println(value);
		 }
		out.println("</BODY>");
		out.println("</HTML>");
		out.flush();
		 out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
