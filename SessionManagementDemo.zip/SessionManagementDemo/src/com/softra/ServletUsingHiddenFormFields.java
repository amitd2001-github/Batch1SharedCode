package com.softra;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletUsingHiddenFormFields
 */
public class ServletUsingHiddenFormFields extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletUsingHiddenFormFields() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		
		 String name = request.getParameter("attrib_name");	
		 String value = request.getParameter("attrib_value");
		 String remove = request.getParameter("attrib_remove");
		
		 out.println("<HTML>");
		 out.println("<HEAD><TITLE>Session Attributes with Hidden Form Fields</TITLE></HEAD>");
		 out.println("<BODY>");
		 out.println("<H1>Session Attributes with Hidden Form Fields</H1>");
		 
		 out.println("Enter name and value of an attribute");
		 //create a HTML Form
		 String url = "/SessionManagementDemo/hiddenformfields";
		 out.println("<FORM ACTION=" + "'" + url + "'" +  " " + "METHOD=GET" + " >");
		 out.println("Name: ");
		 out.println("<INPUT TYPE=\"text\" SIZE=\"10\" NAME=\"attrib_name\">");
		 out.println("Value: ");
		 out.println("<INPUT TYPE=\"text\" SIZE=\"10\" NAME=\"attrib_value\">");
		 
		 //hidden parameters
		 out.println("<INPUT TYPE=\"hidden\" NAME=\"hiddenname\" VALUE=" + name + ">");
		 out.println("<BR>");
		 out.println("<INPUT TYPE=\"hidden\" NAME=\"hiddenvalue\" VALUE=" + value + ">");
		 out.println("<BR>");
		 
		 out.println("<BR><INPUT TYPE=\"checkbox\" NAME=\"attrib_remove\">Remove");
		 out.println("<INPUT TYPE=\"submit\" NAME=\"update\" VALUE=\"Update\">");
		 out.println("</FORM>");
		 
		 out.println("<HR>");
		 out.println("Attributes in this Session using Hidden Form Fields");
		 
		 String name1 = request.getParameter("hiddenname");
		 String value1 = request.getParameter("hiddenvalue");
			
		 out.println("<BR><B>Name:</B> ");
		 out.println(name1);
		 out.println("<B>Value: </B>");
		 out.println(value1);
		 
		 out.println("</BODY>");
		 out.println("</HTML>");
		 
		 out.flush();
		 out.close();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
