package com.softra;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletUsingUrlReWriting
 */
public class ServletUsingUrlReWriting extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletUsingUrlReWriting() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		
		 String name = request.getParameter("attrib_name");	
		 String value = request.getParameter("attrib_value");
		 String remove = request.getParameter("attrib_remove");
		
		 out.println("<HTML>");
		 out.println("<HEAD><TITLE>Session Attributes with URL Re-Writing</TITLE></HEAD>");
		 out.println("<BODY>");
		 out.println("<H1>Session Attributes with URL Re-Writing</H1>");
		 
		 out.println("Enter name and value of an attribute");
		 //create a HTML Form
		 String url = "/SessionManagementDemo/urlrewrite";
		 url = url + "?" + name + "=" + value;
		 
		 out.println("<FORM ACTION=" + "'" + url + "'" +  " " + "METHOD=GET" + " >");
		 out.println("Name: ");
		 out.println("<INPUT TYPE=\"text\" SIZE=\"10\" NAME=\"attrib_name\">");
		 out.println("Value: ");
		 out.println("<INPUT TYPE=\"text\" SIZE=\"10\" NAME=\"attrib_value\">");
		 
		 out.println("<BR><INPUT TYPE=\"checkbox\" NAME=\"attrib_remove\">Remove");
		 out.println("<INPUT TYPE=\"submit\" NAME=\"update\" VALUE=\"Update\">");
		 out.println("</FORM>");
		 
		 out.println("<HR>");
		 out.println("Attributes in this Session using URL Re-Writing");
		 
		 String queryString = request.getQueryString();
			if(queryString != null && queryString.length() > 0)
			{
			StringTokenizer st = new StringTokenizer(queryString,"&");
		     while (st.hasMoreTokens()) {
				 StringTokenizer st1 = new StringTokenizer(st.nextToken(),"=");
				 while (st1.hasMoreTokens()) {
						String name1 = st1.nextToken();
						String value1= st1.nextToken();
						out.println("<BR><B>Name:</B> ");
						out.println(name1);
						out.println("<B>Value: </B>");
						out.println(value1);
				 }     
		     }
		    }
			
		out.println("</BODY>");
		out.println("</HTML>");
		
		out.flush();
		out.close();
		 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
