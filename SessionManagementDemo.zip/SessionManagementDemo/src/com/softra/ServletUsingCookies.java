package com.softra;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.apache.tomcat.util.http.Cookies;

/**
 * Servlet implementation class ServletUsingCookies
 */
public class ServletUsingCookies extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletUsingCookies() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		 out.println("<HTML>");
		 out.println("<HEAD><TITLE>Session Attributes with Cookies</TITLE></HEAD>");
		 out.println("<BODY>");
		 out.println("<H1>Session Attributes with Cookies</H1>");
		 
		 out.println("Enter name and value of an attribute");
		 //create a HTML Form
		 String url = "/SessionManagementDemo/cookies";
		 out.println("<FORM ACTION=" + "'" + url + "'" +  " " + "METHOD=GET" + " >");
		 out.println("Name: ");
		 out.println("<INPUT TYPE=\"text\" SIZE=\"10\" NAME=\"attrib_name\">");
		 out.println("Value: ");
		 out.println("<INPUT TYPE=\"text\" SIZE=\"10\" NAME=\"attrib_value\">");
		 out.println("<BR><INPUT TYPE=\"checkbox\" NAME=\"attrib_remove\">Remove");
		 out.println("<INPUT TYPE=\"submit\" NAME=\"update\" VALUE=\"Update\">");
		 out.println("</FORM>");
		 
		 out.println("<HR>");
		 out.println("Attributes in this Session using Cookie mechanism");
		 //print all the Cookie attributes
		 Cookie[] cookies = request.getCookies();
		 if(cookies !=null)
		 {
		 for(Cookie cookie : cookies)
		 {
			 out.println("<BR><B> Name: </B> ");
			 out.println(cookie.getName());
			 out.println("<B> Value: </B>");
			 out.println(cookie.getValue());
		 }
		 }
		 out.println("</BODY>");
		 out.println("</HTML>");
		 
		
		 String name = request.getParameter("attrib_name");	
		 String value = request.getParameter("attrib_value");
		 if (name != null && name.length() > 0 && (value != null) && value.length() > 0) 
		 {
		   Cookie newcookie = new Cookie(name,value);
		   response.addCookie(newcookie);
		   
		 }
		 
		 out.flush();
		 out.close();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
