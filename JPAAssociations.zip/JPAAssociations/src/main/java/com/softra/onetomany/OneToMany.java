package com.softra.onetomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
//import javax.persistence.OneToMany;

import com.softra.onetomany.Employee;
import com.softra.utility.EntityManagerHelper;

/*
 * ONE-TO-MANY observations - Unidirectional
 * 
 * DEPT table has below values
 * ID	DNAME
 * 4	MicrosoftDepartment
 * 
 * DEPT_EMPLOYEE table has below values
 * DEPT_ID	EMPLOYEES_ID
 * 4	1
 * 4	2
 * 4	3
 * 
 * EMPLOYEE table has below values
 * ID	FIRSTNAME	LASTNAME	
 * 1	Satish		Mandore			
 * 2    Pradip      Dongre      
 * 3	Ajit		Deshpande	
 * 
 */



public class OneToMany {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManager em = EntityManagerHelper.getEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		//Create Employee1 Entity
		Employee employee1 = new Employee();
		employee1.setFname("Satish");
		employee1.setLname("Mandore");
		
		  
		//Create Employee2 Entity
		Employee employee2 = new Employee();
		employee2.setFname("Manish");
		employee2.setLname("Dongre");
		  
		//Create Employee3 Entity
		Employee employee3 = new Employee();
		employee3.setFname("Ajit");
		employee3.setLname("Deshpande");
		   
		//Store Employees
		//em.persist(employee1);
		//em.persist(employee2);
		//em.persist(employee3);
		   
		//Create Employeelist
		List<Employee> emplist = new ArrayList();
		emplist.add(employee1);
		emplist.add(employee2);
		emplist.add(employee3);
		   
		//Create Department Entity
		Department department = new Department();
		department.setName("MicrosoftDepartment");
		department.setEmployees(emplist);
		//employee1.setDepartment(department);
		//em.persist(employee1);
		   
		//Store Department
		em.persist(department);
	
		tx.commit();
		em.close();
		
		EntityManagerHelper.closeFactory();
	}

}

