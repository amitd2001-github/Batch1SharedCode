package com.softra.manytomany;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity(name="EMPL4")
public class Employee {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@Column(name="FIRSTNAME")
	private String fname;
	
	@Column(name="LASTNAME")
	private String lname;
	
	@ManyToMany(targetEntity=TechSkill.class)
	private List<TechSkill> techskills;
	

	public List<TechSkill> getTechskills() {
		return techskills;
	}

	public void setTechskills(List<TechSkill> techskills) {
		this.techskills = techskills;
	}

	public Employee(){
		
	}

	public Employee(int id, String fname, String lname) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}
	
	public String toString(){
		return id + fname;
	}

}
