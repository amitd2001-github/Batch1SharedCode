package com.softra.onetoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.softra.utility.EntityManagerHelper;


/*
 * ONE-TO-ONE observations
 * 
 * ADDR table has below values
 * ID	CITY	ZIP
 * 1	Pune	411004
 * 
 * EMPLOYEE3 table has below values
 * ID	FIRSTNAME	LASTNAME	addr_id	
 * 2	Satish		Mandore		1	
 * 
 * 
 */

public class OneToOne {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerHelper.getEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		//Create Address Entity
		Address addr = new Address();
		addr.setCity("Punwade");
		addr.setZip("411004");
				
		
		//Create Employee1 Entity
		Employee employee1 = new Employee();
		employee1.setFname("Satish");
		employee1.setLname("Potphode");
		employee1.setAddr(addr);
		
		//Store Address
		addr.setEmp(employee1);
		//em.persist(addr);
		   
		//Store Employees
		em.persist(employee1);

		tx.commit();
		em.close();
	}

}
