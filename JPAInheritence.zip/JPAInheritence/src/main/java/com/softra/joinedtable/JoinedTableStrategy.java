package com.softra.joinedtable;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.softra.utility.EntityManagerHelper;

/*
 * JOINED TABLE STRATEGY - TABLE PER SUBCLASS
 * EMPL3 table created with the columns
 * empid	fname	lname	
 * 1		Amit	Deshpande
 * 
 * PERM3 table created with the columns
 * empid	pfacctno
 * 1		101
 * 
 * CONTRA3 table created with the columns
 * empid	contractorName
 * 3		pyramid
 * 
 */

public class JoinedTableStrategy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManager em = EntityManagerHelper.getEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		//Create Permanent Employees
		Employee p1 = new PermanentEmployee(0, "Amit", "Deshpande", 101);
		Employee p2 = new PermanentEmployee(0, "Ajit", "kumar", 102);
		
		//Create Contract Employees
		Employee c1 = new ContractEmployee(0, "Jas", "Arora", "pyramid");
		Employee c2 = new ContractEmployee(0, "Shobha", "Roy", "pyramid");
		
		//Storing all entities
		em.persist(p1);
		em.persist(p2);
		em.persist(c1);
		em.persist(c2);
		
		tx.commit();
		em.close();

		EntityManagerHelper.closeFactory();
	}

}
