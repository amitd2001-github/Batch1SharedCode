package com.softra.singletable;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.softra.utility.EntityManagerHelper;

/*
 * SINGLE TABLE STRATEGY - TABLE PER HIARARCHY
 * EMPLOYEE table created with the columns
 * id	fname	lname	contractorName	pfacctno	EMPTYPE
 */

public class SingleTableStrategy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManager em = EntityManagerHelper.getEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		//Create Permanent Employees
		Employee p1 = new PermanentEmployee(0, "Amit", "Deshpande", 101);
		Employee p2 = new PermanentEmployee(0, "Ajit", "kumar", 102);
		
		//Create Contract Employees
		Employee c1 = new ContractEmployee(0, "Jas", "Arora", "pyramid");
		Employee c2 = new ContractEmployee(0, "Shobhna", "Roy", "pyramid");
		
		//Storing all entities
		em.persist(p1);
		em.persist(p2);
		em.persist(c1);
		em.persist(c2);
		
		tx.commit();
		em.close();
		
		EntityManagerHelper.closeFactory();

	}

}
