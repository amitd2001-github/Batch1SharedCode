package com.softra.tableperclass;

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Employee
 *
 */
@Entity(name="EMPL2")
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class Employee implements Serializable {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private int empid;
    
	private String fname;
	
	private String lname;
	private static final long serialVersionUID = 1L;

	public Employee() {
		super();
	}   
	
	
	public Employee(int id, String fname, String lname) {
		super();
		this.empid = id;
		this.fname = fname;
		this.lname = lname;
	}


	public int getId() {
		return this.empid;
	}

	public void setId(int id) {
		this.empid = id;
	}   
	public String getFname() {
		return this.fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}   
	public String getLname() {
		return this.lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}
	
	public String toString(){
		return empid + fname;
	}
   
}
