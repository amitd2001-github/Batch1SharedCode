package com.softra.tableperclass;


import javax.persistence.Entity;


@Entity(name="PERM2")
public class PermanentEmployee extends Employee {
	
	private int pfacctno;

	public int getPfacctno() {
		return pfacctno;
	}

	public void setPfacctno(int pfacctno) {
		this.pfacctno = pfacctno;
	}

	public PermanentEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PermanentEmployee(int id, String fname, String lname, int pfacct) {
		super(id, fname, lname);
		this.pfacctno = pfacct;
	}
	
}
