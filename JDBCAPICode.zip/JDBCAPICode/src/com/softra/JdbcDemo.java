package com.softra;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcDemo {

	public static void main(String[] args) {
		
		String driverClassName = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/jdbcapi";
		String username = "root";
		String password = "root";		
		
		try {
			Class.forName(driverClassName);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			Connection con = DriverManager.getConnection(url, username, password);
			Statement statement = con.createStatement();
			statement.executeUpdate("insert into empl(id,name) values (11,'Amit')");
			statement.executeUpdate("insert into empl(id,name) values (12,'Ajit')");
			ResultSet rs = statement.executeQuery("select * from empl");
			while( rs.next() ){
				int id = rs.getInt("id");
				String name =  rs.getString("name");
				System.out.println( id + ":" + name );
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

/*
 CREATE TABLE `jdbcapi`.`EMPL` (
  `id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(15) NOT NULL,
  PRIMARY KEY (`id`)
)
ENGINE = InnoDB;
*/

