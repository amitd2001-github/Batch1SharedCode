package com.softra;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("aop.xml");
		Iservice service = context.getBean("service",Iservice.class);
		
		List<Employee> list = new ArrayList<>();
		list.add(new Employee(12,"Amitaa","Deshpande"));
		list.add(new Employee(13,"Sumitaa","Raghavan"));
		
		service.saveEmployees(list);

	}

}
