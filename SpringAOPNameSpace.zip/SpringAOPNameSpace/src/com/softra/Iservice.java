package com.softra;

import java.util.List;

public interface Iservice {

	void saveEmployees(List<Employee> list);
	void modifyEmployees(List<Employee> list);
}
