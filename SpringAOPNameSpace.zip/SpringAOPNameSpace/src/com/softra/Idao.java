package com.softra;

public interface Idao {

	void saveEmployee(Employee e);
	void modifyEmployee(Employee e);
}
