package com.softra;

public interface ILogging {

	void writeLog();
}
