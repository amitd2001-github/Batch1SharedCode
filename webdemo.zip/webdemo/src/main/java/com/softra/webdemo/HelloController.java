package com.softra.webdemo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

//http://localhost:7777/hello

@Controller
public class HelloController {

	@RequestMapping(value="/hello",method=RequestMethod.GET)
	public ModelAndView sayHello() {
		System.out.println("inside sayHello()");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("hello");
		String model = "Amit Kumar";
		mav.addObject("msg",model);
		return mav;
	}
}
