package com.softra;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class HRDept implements ApplicationContextAware {

	private ApplicationContext ctx;
	
	public void recruitEmployee() {
		System.out.println("employee is recruited");
		ctx.publishEvent(new EmployeeRecruitEvent(this));
	}

	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		this.ctx = arg0;
		
	}
	
	
	
}
