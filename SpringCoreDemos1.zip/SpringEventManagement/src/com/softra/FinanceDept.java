package com.softra;

import org.springframework.context.ApplicationListener;

public class FinanceDept implements ApplicationListener<EmployeeRecruitEvent> {

	@Override
	public void onApplicationEvent(EmployeeRecruitEvent event) {
		System.out.println("Finance dept started the processing of new empl");
	}

}
