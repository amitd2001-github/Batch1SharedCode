package com.softra;

import org.springframework.context.ApplicationEvent;

public class EmployeeRecruitEvent extends ApplicationEvent {

	public EmployeeRecruitEvent(Object source) {
		super(source);
		
	}

}
