package com.softra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		
		ApplicationContext context  = 
				new ClassPathXmlApplicationContext("reports.xml");
		
		ReportService rs = context.getBean("rs",ReportService.class);
		
		rs.generateReport();
		
		ConfigurableApplicationContext confctx = 
				(ConfigurableApplicationContext)context;
		
		confctx.close();
		
		

	}

}
