package com.softra;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class ReportService {

	private String filename;
	private PrintWriter writer;

	public ReportService() {
		System.out.println("inside constructor of ReportService");
	}
	
	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		System.out.println("inside setFilename");
		this.filename = filename;
	}
	
	public void doinit() {
		System.out.println("inside doinit");
		try {
			writer = new PrintWriter(filename);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void generateReport() {
		System.out.println("inside generateReport");
		
		writer.write("generating a report...");
	}
	
	public void close() {
		writer.close();
	}
	
}
