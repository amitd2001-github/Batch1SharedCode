package com.softra;

import java.beans.PropertyEditorSupport;

public class PhoneNumberEditor extends PropertyEditorSupport {

	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		
		System.out.println("inside PhoneNumberEditor");
		Phone phone = new Phone();
		phone.setCountryCode(text.substring(0, 2));
		phone.setCityCode(text.substring(2,4));
		phone.setNumber(text.substring(5));
		
		setValue(phone);

	}
	
	

}
