package com.softra;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

public class EmployeeValidator implements Validator {

	@Override
	public boolean supports(Class clas) {
		return Employee.class.equals(clas);
	}

	@Override
	public void validate(Object target, Errors errors) {
		System.out.println("inside validate() method");
		Employee emp = (Employee)target;
		
		ValidationUtils.rejectIfEmpty(errors, "fname", "fname.error");
	}

}


/*if(emp.getFname().equals(null) || emp.getFname().trim().equals(""))
{
	errors.rejectValue("fname", "fname.error");		
}*/