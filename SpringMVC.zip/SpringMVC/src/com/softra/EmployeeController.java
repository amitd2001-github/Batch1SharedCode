package com.softra;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

@Controller
public class EmployeeController {
	
	@Autowired
	private Iservice service;

	/*
	 * 1. default method is GET only. no need to specify explicitly
	 */
	@RequestMapping(value="/changeLocale.htm",method=RequestMethod.GET)
	public String changeLocale(@RequestParam String lang,HttpServletRequest req,Model model)
	{
		System.out.println("inside changeLocale()" + lang);
		
		HttpSession session =  req.getSession();	
		session.setAttribute(
				SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME, new Locale(lang));
		
		model.addAttribute("emp", new Employee());
		
		return "redirect:saveemp.htm";
	}
	
	
	@RequestMapping(value="/saveemp.htm",method=RequestMethod.GET)
	public String showEmpForm(Map<String,Employee> map)
	{
		System.out.println("inside showEmpForm()");
		map.put("emp", new Employee());
		return "empForm";
	}
	
	
	/*
	 * 1. If request parameter name is same as variable name no need to write @RequestParam
	 */
	//@RequestMapping(method=RequestMethod.POST)
	//public String saveEmployee(@RequestParam("empid") int id, String fname, String lname,Map map)
	/*public String saveEmployee(@ModelAttribute("emp") Employee e,Map map)
	{
		System.out.println("inside saveEmployee()");
		/*System.out.println("id :" + id);
		System.out.println("fname :" + fname);
		System.out.println("lname :" + lname);
		
		e = new Employee(id,fname,lname);*/
		
		/*map.put("emp", e);
		return "savedetails";	
	}*/
	
	
	/*
	 * 1. Instead of adding all arguments in method we can directly add @ModelAttribute.
	 * 2. @ModelAttribute is like what was Command object in previous release.
	 *    variable names in Model should match with request parameter names.
	 */
	//@RequestMapping(method=RequestMethod.POST)
	/*public String saveEmployee(@ModelAttribute("emp") Employee e)
	{
		System.out.println("inside saveEmployee() taking ModelAttribute");
		return "savedetails";	
	}*/

	
	/*
	 * 1. In @ModelAttribute, binding is done for employee object from request. If some exception occur for e.g. 
	 *    Id=string will get NumberFormatException, to handle such thing add a method param 'BindingResult'.  

	 */
	@RequestMapping(value="/saveemp.htm", method=RequestMethod.POST)
	public String saveEmployee(@Valid @ModelAttribute("emp") Employee e, BindingResult result,Map map)
	{
		System.out.println("inside saveEmployee() of EmployeeController");
		EmployeeValidator empval = new EmployeeValidator();
		empval.validate(e, result);
		
		if(result.hasErrors()) {
			System.out.println("validation errors");
			return "empForm";
		}
			
		
		List<Employee> list = new ArrayList<>();
		list.add(e);
		service.saveEmployees(list);
		
		/*if(true)
		{
			throw new RuntimeException("This is testing exception");
		}*/
		map.put("emp", e);
		
		System.out.println("inside saveEmployee() taking ModelAttribute and BindingResult");
		return "savedetails";	
		
	}
	
	/*
	 * 1. If bean SimpleMappingExceptionResolver is defined in Spring xml, then it will take
	 *    the precedence over this @ExceptionHandler annotated method.
	 */
	@ExceptionHandler({RuntimeException.class,IOException.class})
	public String resolveException()
	{
		System.out.println("inside resolveException()");
		return "error";
	}
}
