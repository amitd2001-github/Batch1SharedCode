package com.softra;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository(value = "jpadao")
public class EmployeeJpaDao implements Idao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public void saveEmployee(Employee e) {
		System.out.println("inside saveEmployee of EmployeeJpaDao " + entityManager);
		try {
			
			entityManager.persist(e);
			entityManager.flush();
			
		}catch(Exception exp) {
			System.out.println("Exception occured " + exp );
			exp.printStackTrace();
		}
		

	}

	@Override
	public void modifyEmployee(Employee e) {
		// TODO Auto-generated method stub

	}

}
