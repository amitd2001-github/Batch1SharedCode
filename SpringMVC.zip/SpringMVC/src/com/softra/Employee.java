package com.softra;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
//import javax.validation.constraints.NotEmpty;
//import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

//import org.hibernate.validator.constraints.NotEmpty;

/*import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;*/

@Entity(name = "employee")
public class Employee {
	
	@Id
	private int id;
	
	@Column
	private String fname;
	
	@Size(min=3, max=4)
	@NotEmpty
	@Column
	private String lname;
	
	public Employee()
	{
		
	}
	
	public Employee(int empid, String fname, String lname) {
		super();
		this.id = empid;
		this.fname = fname;
		this.lname = lname;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	
	public String toString() {
		return id+fname+lname;
	}
	

}
