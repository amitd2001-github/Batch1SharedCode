package com.softra;

import java.util.Map;

//import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
//import org.springframework.security.access.annotation.Secured;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.BeanNameUrlHandlerMapping;

@Controller
@RequestMapping("/welcome")
public class WelcomeController {
	

	@RequestMapping(method=RequestMethod.GET,value="/abc.htm")
	public String sayWelcome1()
	{
		//URL = /welcome/abc.htm
		System.out.println("inside sayWelcome1() method of WelcomeController ...");
		return "hello";
	}
	
	@RequestMapping(method=RequestMethod.GET,value={"/pqr.htm"})
	public String sayWelcome2(Model model)
	{
		//URL = /welcome/pqr.htm
		System.out.println("inside sayWelcome2() method of WelcomeController ...");
		String msg = "Spring MVC using Annotations using Model";
		model.addAttribute("msg",msg);
		return "hello";
	}
	
	@RequestMapping(method=RequestMethod.GET,value={"/xyz.htm"})
	public String sayWelcome3(Map<String,String> map)
	{
		//URL = /welcome/xyz.htm
		System.out.println("inside sayWelcome3() method of WelcomeController ...");
		String msg = "Spring MVC using Annotations using Map";
		map.put("msg",msg);
		return "hello";
	}

}
